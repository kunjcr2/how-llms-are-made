"""
Count materials
Loop through brands
Loop through materials
Store trending items
Check counts
Return results
"""


def find_trending_materials(brands):

    material_count = {}
    
    for brand in brands:
        for material in brand["materials"]:
            if material in material_count:
                material_count[material] += 1
            else:
                material_count[material] = 1
                
    trending = []
    for material in material_count:
        if material_count[material] > 1:
            trending.append(material)
            
    return trending 


brands = [
    {"name": "EcoWear", "materials": ["organic cotton", "recycled polyester"]},
    {"name": "GreenThreads", "materials": ["organic cotton", "bamboo"]},
    {"name": "SustainableStyle", "materials": ["bamboo", "recycled polyester"]}
]

brands_2 = [
    {"name": "NatureWear", "materials": ["hemp", "linen"]},
    {"name": "Earthly", "materials": ["organic cotton", "hemp"]},
    {"name": "GreenFit", "materials": ["linen", "recycled wool"]}
]

brands_3 = [
    {"name": "OrganicThreads", "materials": ["organic cotton"]},
    {"name": "EcoFashion", "materials": ["recycled polyester", "hemp"]},
    {"name": "GreenLife", "materials": ["recycled polyester", "bamboo"]}
]

print(find_trending_materials(brands))
print(find_trending_materials(brands_2))
print(find_trending_materials(brands_3))

# ['organic cotton', 'recycled polyester', 'bamboo']
# ['hemp', 'linen']
# ['recycled polyester']
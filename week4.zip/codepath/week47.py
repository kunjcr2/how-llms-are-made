def calculate_fabric_waste(items, fabric_rolls):
    total_waste = 0

    for i in range(len(items)):
        required_len = items[i][1]
        roll_len = fabric_rolls[i]
        total_waste += required_len - roll_len

    return total_waste


items = [("T-Shirt", 2), ("Pants", 3), ("Jacket", 5)]
fabric_rolls = [5, 5, 5]

items_2 = [("Dress", 4), ("Skirt", 3), ("Blouse", 2)]
fabric_rolls = [4, 4, 4]

items_3 = [("Jacket", 6), ("Shirt", 2), ("Shorts", 3)]
fabric_rolls = [7, 5, 5]

print(calculate_fabric_waste(items, fabric_rolls))
print(calculate_fabric_waste(items_2, fabric_rolls))
print(calculate_fabric_waste(items_3, fabric_rolls))

# 5
# 3
# 6
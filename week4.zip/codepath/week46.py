def process_supplies(supplies):
        
    sorted_supplies = sorted(supplies, key = lambda x: x[1], reverse = True)
    
    names = []
    for supply in sorted_supplies:
        names.append(supply[0])
        
    return names


supplies = [("Organic Cotton", 3), ("Recycled Polyester", 2), ("Bamboo", 4), ("Hemp", 1)]
supplies_2 = [("Linen", 2), ("Recycled Wool", 5), ("Tencel", 3), ("Organic Cotton", 4)]
supplies_3 = [("Linen", 3), ("Hemp", 2), ("Recycled Polyester", 5), ("Bamboo", 1)]

print(process_supplies(supplies))
print(process_supplies(supplies_2))
print(process_supplies(supplies_3))

# ['Bamboo', 'Organic Cotton', 'Recycled Polyester', 'Hemp']
# ['Recycled Wool', 'Organic Cotton', 'Tencel', 'Linen']
# ['Recycled Polyester', 'Linen', 'Hemp', 'Bamboo']
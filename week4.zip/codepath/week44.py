"""

"""

def find_best_fabric_pair(fabrics, budget):
    sorted_fabrics = sorted(fabrics, key=lambda x: x[1])
    
    start = 0
    end = len(sorted_fabrics) - 1

    
    while start != end:
        if sorted_fabrics[start][1] + sorted_fabrics[end][1] == budget:
            return sorted_fabrics[start][0], sorted_fabrics[end][0]
        elif sorted_fabrics[start][1] + sorted_fabrics[end][1] > budget:
            end -= 1
        else:
            start += 1


    return -1, -1

        
fabrics = [("Organic Cotton", 30), 
           ("Recycled Polyester", 20), 
           ("Bamboo", 25), 
           ("Hemp", 15)
           ]

fabrics_2 = [("Linen", 50), ("Recycled Wool", 40), ("Tencel", 30), ("Organic Cotton", 60)]
fabrics_3 = [("Linen", 40), ("Hemp", 35), ("Recycled Polyester", 25), ("Bamboo", 20)]

print(find_best_fabric_pair(fabrics, 45))
print(find_best_fabric_pair(fabrics_2, 70))
print(find_best_fabric_pair(fabrics_3, 60))

# ('Hemp', 'Organic Cotton')
# ('Tencel', 'Recycled Wool')
# ('Bamboo', 'Linen')